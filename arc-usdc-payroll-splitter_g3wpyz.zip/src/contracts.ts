/**
 * BatchPayroll contract config — Arc Testnet
 * Deployed: 0x5699c781941cc1d2fa7d432827824d2520305bf6
 */

export const BATCH_PAYROLL = {
  address: '0x5699c781941cc1d2fa7d432827824d2520305bf6' as const,
  abi: [
    {
      type: 'constructor',
      inputs: [{ name: '_usdc', type: 'address', internalType: 'address' }],
      stateMutability: 'nonpayable',
    },
    {
      type: 'function',
      name: 'MAX_BATCH',
      inputs: [],
      outputs: [{ name: '', type: 'uint256', internalType: 'uint256' }],
      stateMutability: 'view',
    },
    {
      type: 'function',
      name: 'dispatchBatch',
      inputs: [
        { name: 'recipients', type: 'address[]', internalType: 'address[]' },
        { name: 'amounts', type: 'uint256[]', internalType: 'uint256[]' },
      ],
      outputs: [],
      stateMutability: 'nonpayable',
    },
    {
      type: 'function',
      name: 'usdc',
      inputs: [],
      outputs: [{ name: '', type: 'address', internalType: 'address' }],
      stateMutability: 'view',
    },
    {
      type: 'event',
      name: 'BatchDispatched',
      inputs: [
        { name: 'payer', type: 'address', indexed: true, internalType: 'address' },
        { name: 'total', type: 'uint256', indexed: false, internalType: 'uint256' },
        { name: 'recipients', type: 'address[]', indexed: false, internalType: 'address[]' },
        { name: 'amounts', type: 'uint256[]', indexed: false, internalType: 'uint256[]' },
      ],
      anonymous: false,
    },
    { type: 'error', name: 'BatchTooLarge', inputs: [{ name: 'length', type: 'uint256', internalType: 'uint256' }, { name: 'max', type: 'uint256', internalType: 'uint256' }] },
    { type: 'error', name: 'EmptyBatch', inputs: [] },
    { type: 'error', name: 'LengthMismatch', inputs: [] },
    { type: 'error', name: 'ReentrancyGuardReentrantCall', inputs: [] },
    { type: 'error', name: 'SafeERC20FailedOperation', inputs: [{ name: 'token', type: 'address', internalType: 'address' }] },
    { type: 'error', name: 'ZeroAmount', inputs: [{ name: 'index', type: 'uint256', internalType: 'uint256' }] },
    { type: 'error', name: 'ZeroRecipient', inputs: [{ name: 'index', type: 'uint256', internalType: 'uint256' }] },
    { type: 'error', name: 'ZeroUSDCAddress', inputs: [] },
  ] as const,
}
