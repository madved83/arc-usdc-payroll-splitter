/**
 * BatchPayroll — USDC Payroll Dispatcher on Arc
 * Built with Arc Studio
 */

import { useState, useCallback, useEffect } from 'react'
import { useAccount, useWriteContract, useWaitForTransactionReceipt, useSwitchChain, useReadContract, usePublicClient } from 'wagmi'
import { ConnectKitButton } from 'connectkit'
import { erc20Abi, isAddress, parseAbiItem } from 'viem'
import { arcTestnet } from 'viem/chains'
import { toast } from 'sonner'
import { Plus, Trash2, Send, CheckCircle2, ExternalLink, AlertCircle, Users, DollarSign, ChevronDown, Upload } from 'lucide-react'
import { TokenUSDC } from '@web3icons/react'
import { getUsdc, buildTxExplorerUrl } from '@/onchain-facts'
import { parseAmount, formatAmount, usdcDecimalsFor, Amount } from '@/onchain-money'
import { BATCH_PAYROLL } from './contracts'

const CHAIN_ID = arcTestnet.id
const USDC_FACT = getUsdc(CHAIN_ID)!
const USDC_ADDRESS = USDC_FACT.address as `0x${string}`

// ─── Types ───────────────────────────────────────────────────────────────────

interface PayrollRow {
  id: string
  address: string
  amount: string
}

interface HistoryEntry {
  txHash: string
  payer: string
  total: bigint
  recipients: string[]
  amounts: bigint[]
  timestamp: number
}

// ─── Utilities ────────────────────────────────────────────────────────────────

function shortAddr(addr: string) {
  return addr.slice(0, 6) + '…' + addr.slice(-4)
}

function formatUsdc(raw: bigint): string {
  return Amount.fromRaw(raw, usdcDecimalsFor(CHAIN_ID)).toFixed(2)
}

function formatUsdcBalance(raw: bigint): string {
  return formatAmount(CHAIN_ID, Amount.fromRaw(raw, usdcDecimalsFor(CHAIN_ID)))
}

function parseOnchainError(err: unknown): string {
  const msg = (err as Error)?.message?.toLowerCase() ?? ''
  if (msg.includes('user rejected') || msg.includes('user denied')) return 'Transaction cancelled.'
  if (msg.includes('insufficient')) return 'Insufficient USDC balance or allowance.'
  if (msg.includes('emptybatch')) return 'Batch cannot be empty.'
  if (msg.includes('lengthmismatch')) return 'Recipients and amounts must match in length.'
  if (msg.includes('batchtoolarge')) return 'Too many recipients (max 200).'
  if (msg.includes('zeroamount')) return 'Amounts cannot be zero.'
  if (msg.includes('zerorecipient')) return 'Recipient addresses cannot be zero.'
  if (msg.includes('reverted')) return 'Transaction reverted. Check allowance and balances.'
  return 'Something went wrong. Please try again.'
}

function newRow(): PayrollRow {
  return { id: crypto.randomUUID(), address: '', amount: '' }
}

// ─── Components ───────────────────────────────────────────────────────────────

function ConnectBanner() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] gap-6 text-center px-4">
      <div className="w-14 h-14 rounded-2xl flex items-center justify-center" style={{ background: 'var(--surface-muted)', border: '1px solid var(--border)' }}>
        <Users size={28} style={{ color: 'var(--accent)' }} />
      </div>
      <div>
        <h2 className="display text-2xl font-semibold mb-2" style={{ color: 'var(--ink)' }}>Connect your wallet</h2>
        <p className="text-sm" style={{ color: 'var(--muted)' }}>Connect to Arc Testnet to dispatch USDC payroll batches</p>
      </div>
      <ConnectKitButton />
    </div>
  )
}

function WrongChainBanner() {
  const { switchChain, isPending } = useSwitchChain()
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] gap-6 text-center px-4">
      <div className="w-14 h-14 rounded-2xl flex items-center justify-center" style={{ background: '#fff3f5', border: '1px solid rgba(186,43,76,0.2)' }}>
        <AlertCircle size={28} style={{ color: 'var(--danger)' }} />
      </div>
      <div>
        <h2 className="display text-2xl font-semibold mb-2" style={{ color: 'var(--ink)' }}>Wrong network</h2>
        <p className="text-sm mb-4" style={{ color: 'var(--muted)' }}>Switch to Arc Testnet to use BatchPayroll</p>
      </div>
      <button
        onClick={() => switchChain({ chainId: CHAIN_ID })}
        disabled={isPending}
        className="px-6 py-3 rounded-xl text-sm font-semibold transition-colors"
        style={{ background: 'var(--accent)', color: '#fff', opacity: isPending ? 0.6 : 1 }}
      >
        {isPending ? 'Switching…' : 'Switch to Arc Testnet'}
      </button>
    </div>
  )
}

// ─── Payroll Row Input ─────────────────────────────────────────────────────────

function PayrollRowInput({ row, idx, onChange, onRemove, canRemove }: {
  row: PayrollRow
  idx: number
  onChange: (id: string, field: 'address' | 'amount', value: string) => void
  onRemove: (id: string) => void
  canRemove: boolean
}) {
  const addrValid = row.address === '' || isAddress(row.address)
  const amtValid = row.amount === '' || (!isNaN(parseFloat(row.amount)) && parseFloat(row.amount) > 0)

  return (
    <div className="flex gap-2 items-start">
      <span className="text-xs font-medium pt-3 w-5 text-right shrink-0 tabular-nums" style={{ color: 'var(--subtle)' }}>
        {idx + 1}
      </span>
      <div className="flex-1 flex flex-col sm:flex-row gap-2">
        <div className="flex-1 relative">
          <input
            type="text"
            placeholder="0x recipient address"
            value={row.address}
            onChange={e => onChange(row.id, 'address', e.target.value)}
            spellCheck={false}
            className="w-full px-3 py-2.5 rounded-xl text-sm mono transition-colors outline-none"
            style={{
              background: 'var(--surface-strong)',
              border: `1px solid ${!addrValid && row.address ? 'var(--danger)' : 'var(--border)'}`,
              color: 'var(--ink)',
            }}
          />
          {!addrValid && row.address && (
            <p className="text-xs mt-1" style={{ color: 'var(--danger)' }}>Invalid address</p>
          )}
        </div>
        <div className="sm:w-36 relative">
          <input
            type="number"
            placeholder="0.00"
            min="0"
            step="0.01"
            value={row.amount}
            onChange={e => onChange(row.id, 'amount', e.target.value)}
            className="w-full px-3 py-2.5 rounded-xl text-sm tabular-nums transition-colors outline-none"
            style={{
              background: 'var(--surface-strong)',
              border: `1px solid ${!amtValid && row.amount ? 'var(--danger)' : 'var(--border)'}`,
              color: 'var(--ink)',
            }}
          />
          {!amtValid && row.amount && (
            <p className="text-xs mt-1" style={{ color: 'var(--danger)' }}>Invalid amount</p>
          )}
        </div>
      </div>
      <button
        onClick={() => onRemove(row.id)}
        disabled={!canRemove}
        className="mt-1 p-2 rounded-lg transition-colors"
        style={{ color: canRemove ? 'var(--danger)' : 'var(--border)', background: 'transparent' }}
        aria-label="Remove row"
      >
        <Trash2 size={16} />
      </button>
    </div>
  )
}

// ─── History Table ─────────────────────────────────────────────────────────────

function HistoryTable({ entries }: { entries: HistoryEntry[] }) {
  const [expanded, setExpanded] = useState<string | null>(null)

  if (entries.length === 0) {
    return (
      <div className="text-center py-8" style={{ color: 'var(--subtle)' }}>
        <p className="text-sm">No transactions yet</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-2">
      {entries.map(entry => (
        <div
          key={entry.txHash}
          className="rounded-xl overflow-hidden"
          style={{ border: '1px solid var(--border)', background: 'var(--surface)' }}
        >
          <button
            className="w-full flex items-center justify-between px-4 py-3 gap-4 text-left hover:bg-white/30 transition-colors"
            onClick={() => setExpanded(expanded === entry.txHash ? null : entry.txHash)}
          >
            <div className="flex items-center gap-3 min-w-0">
              <CheckCircle2 size={16} style={{ color: 'var(--success)', flexShrink: 0 }} />
              <div className="min-w-0">
                <p className="text-sm font-medium mono truncate" style={{ color: 'var(--ink)' }}>
                  {shortAddr(entry.txHash)}
                </p>
                <p className="text-xs" style={{ color: 'var(--subtle)' }}>
                  {new Date(entry.timestamp).toLocaleString()} · {entry.recipients.length} recipient{entry.recipients.length !== 1 ? 's' : ''}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <div className="text-right">
                <p className="text-sm font-semibold tabular-nums" style={{ color: 'var(--ink)' }}>
                  {formatUsdc(entry.total)} USDC
                </p>
              </div>
              <div className="flex gap-1">
                <a
                  href={buildTxExplorerUrl(CHAIN_ID, entry.txHash)}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={e => e.stopPropagation()}
                  className="p-1.5 rounded-lg transition-colors hover:bg-white/50"
                  style={{ color: 'var(--muted)' }}
                  aria-label="View on explorer"
                >
                  <ExternalLink size={14} />
                </a>
                <span className="p-1.5" style={{ color: 'var(--subtle)', transform: expanded === entry.txHash ? 'rotate(180deg)' : 'rotate(0)', display: 'inline-block', transition: 'transform 0.2s' }}>
                  <ChevronDown size={14} />
                </span>
              </div>
            </div>
          </button>

          {expanded === entry.txHash && (
            <div className="border-t" style={{ borderColor: 'var(--border)' }}>
              <div className="px-4 py-3">
                <table className="w-full text-sm">
                  <thead>
                    <tr>
                      <th className="text-left pb-2 text-xs font-medium" style={{ color: 'var(--subtle)' }}>#</th>
                      <th className="text-left pb-2 text-xs font-medium" style={{ color: 'var(--subtle)' }}>Recipient</th>
                      <th className="text-right pb-2 text-xs font-medium" style={{ color: 'var(--subtle)' }}>Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {entry.recipients.map((r, i) => (
                      <tr key={i} className="border-t" style={{ borderColor: 'var(--border)' }}>
                        <td className="py-2 pr-3 text-xs tabular-nums" style={{ color: 'var(--subtle)' }}>{i + 1}</td>
                        <td className="py-2 pr-3">
                          <a
                            href={`https://explorer.testnet.arc.io/address/${r}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="mono text-xs hover:underline"
                            style={{ color: 'var(--accent-hover)' }}
                          >
                            {shortAddr(r)}
                          </a>
                        </td>
                        <td className="py-2 text-right mono text-xs tabular-nums font-medium" style={{ color: 'var(--ink)' }}>
                          {formatUsdc(entry.amounts[i])} USDC
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  )
}

// ─── Main App ─────────────────────────────────────────────────────────────────

export default function App() {
  const { address, isConnected, chainId } = useAccount()

  const [rows, setRows] = useState<PayrollRow[]>([newRow(), newRow()])
  const [history, setHistory] = useState<HistoryEntry[]>([])
  const [activeTab, setActiveTab] = useState<'batch' | 'history'>('batch')
  const [csvError, setCsvError] = useState<string | null>(null)

  // ── USDC balance ──
  const { data: usdcBalance } = useReadContract({
    address: USDC_ADDRESS,
    abi: erc20Abi,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    chainId: CHAIN_ID,
    query: { enabled: !!address },
  })

  // ── Derived batch data ──
  const validRows = rows.filter(r => isAddress(r.address) && r.amount !== '' && parseFloat(r.amount) > 0)
  const totalRaw = validRows.reduce((acc, r) => {
    try {
      return acc + parseAmount(CHAIN_ID, r.amount).raw
    } catch {
      return acc
    }
  }, 0n)
  const hasValidBatch = validRows.length > 0 && validRows.length === rows.filter(r => r.address || r.amount).length

  // ── Approve step ──
  const {
    writeContract: approveWrite,
    data: approveHash,
    isPending: approvePending,
    reset: approveReset,
  } = useWriteContract()

  const {
    isLoading: approveConfirming,
    isSuccess: approveSuccess,
  } = useWaitForTransactionReceipt({ hash: approveHash })

  // ── Dispatch step ──
  const {
    writeContract: dispatchWrite,
    data: dispatchHash,
    isPending: dispatchPending,
    reset: dispatchReset,
  } = useWriteContract()

  const {
    isLoading: dispatchConfirming,
    isSuccess: dispatchSuccess,
    data: dispatchReceipt,
  } = useWaitForTransactionReceipt({ hash: dispatchHash })

  const publicClient = usePublicClient({ chainId: CHAIN_ID })

  // ── Watch dispatch success ──
  useEffect(() => {
    if (!dispatchSuccess || !dispatchHash || !dispatchReceipt || !publicClient) return

    const fetchLogs = async () => {
      try {
        const logs = await publicClient.getLogs({
          address: BATCH_PAYROLL.address,
          event: parseAbiItem('event BatchDispatched(address indexed payer, uint256 total, address[] recipients, uint256[] amounts)'),
          fromBlock: dispatchReceipt.blockNumber,
          toBlock: dispatchReceipt.blockNumber,
        })

        if (logs.length > 0) {
          const log = logs[0]
          const entry: HistoryEntry = {
            txHash: dispatchHash,
            payer: log.args.payer as string,
            total: log.args.total as bigint,
            recipients: log.args.recipients as string[],
            amounts: log.args.amounts as bigint[],
            timestamp: Date.now(),
          }
          setHistory(prev => [entry, ...prev])
        }
      } catch {
        // fallback: build entry from form state
        const entry: HistoryEntry = {
          txHash: dispatchHash,
          payer: address ?? '',
          total: totalRaw,
          recipients: validRows.map(r => r.address),
          amounts: validRows.map(r => {
            try { return parseAmount(CHAIN_ID, r.amount).raw } catch { return 0n }
          }),
          timestamp: Date.now(),
        }
        setHistory(prev => [entry, ...prev])
      }

      toast.success('Payroll dispatched!', { description: `${validRows.length} recipient${validRows.length !== 1 ? 's' : ''} paid` })
      setRows([newRow(), newRow()])
      approveReset()
      dispatchReset()
      setActiveTab('history')
    }

    void fetchLogs()
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatchSuccess])

  // ── Row handlers ──
  const handleRowChange = useCallback((id: string, field: 'address' | 'amount', value: string) => {
    setRows(prev => prev.map(r => r.id === id ? { ...r, [field]: value } : r))
  }, [])

  const handleAddRow = () => setRows(prev => [...prev, newRow()])

  const handleRemoveRow = (id: string) => setRows(prev => prev.filter(r => r.id !== id))

  // ── CSV paste / import ──
  const handleCsvPaste = (text: string) => {
    setCsvError(null)
    const lines = text.trim().split('\n').filter(Boolean)
    const parsed: PayrollRow[] = []
    for (const line of lines) {
      const parts = line.split(/[,\t]/).map(s => s.trim())
      if (parts.length < 2) { setCsvError('Each line needs an address and an amount (comma or tab separated)'); return }
      const [addr, amt] = parts
      parsed.push({ id: crypto.randomUUID(), address: addr, amount: amt })
    }
    setRows(parsed)
    toast.info(`Loaded ${parsed.length} rows from CSV`)
  }

  const handleCsvDrop = (e: React.DragEvent) => {
    e.preventDefault()
    const file = e.dataTransfer.files[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = ev => handleCsvPaste((ev.target?.result as string) ?? '')
    reader.readAsText(file)
  }

  const handleCsvInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = ev => handleCsvPaste((ev.target?.result as string) ?? '')
    reader.readAsText(file)
  }

  // ── Transaction flow ──
  const handleApprove = () => {
    if (!address || !hasValidBatch) return
    approveWrite({
      address: USDC_ADDRESS,
      abi: erc20Abi,
      functionName: 'approve',
      args: [BATCH_PAYROLL.address, totalRaw],
      chainId: CHAIN_ID,
    })
  }

  const handleDispatch = () => {
    if (!address || !hasValidBatch) return
    dispatchWrite({
      address: BATCH_PAYROLL.address,
      abi: BATCH_PAYROLL.abi,
      functionName: 'dispatchBatch',
      args: [
        validRows.map(r => r.address as `0x${string}`),
        validRows.map(r => parseAmount(CHAIN_ID, r.amount).raw),
      ],
      chainId: CHAIN_ID,
    })
  }

  const handleError = (err: unknown) => {
    toast.error(parseOnchainError(err))
  }

  // ── Render states ──
  if (!isConnected) return <ConnectBanner />
  if (chainId !== CHAIN_ID) return <WrongChainBanner />

  const isBusy = approvePending || approveConfirming || dispatchPending || dispatchConfirming
  const formattedBalance = usdcBalance !== undefined ? formatUsdcBalance(usdcBalance) : '—'
  const filledRows = rows.filter(r => r.address || r.amount)

  return (
    <div className="min-h-dvh" style={{ background: 'var(--bg-gradient)' }}>
      {/* Header */}
      <header className="sticky top-0 z-10 px-4 py-3 flex items-center justify-between" style={{ background: 'var(--surface)', backdropFilter: 'blur(16px)', borderBottom: '1px solid var(--border)' }}>
        <div className="flex items-center gap-2.5">
          <TokenUSDC variant="branded" size={28} />
          <span className="display text-base font-semibold" style={{ color: 'var(--ink)' }}>BatchPayroll</span>
          <span className="hidden sm:inline text-xs px-2 py-0.5 rounded-full font-medium" style={{ background: 'var(--surface-muted)', color: 'var(--muted)' }}>Arc Testnet</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-1.5 text-sm tabular-nums" style={{ color: 'var(--ink-2)' }}>
            <DollarSign size={14} style={{ color: 'var(--muted)' }} />
            <span className="font-medium">{formattedBalance}</span>
            <span style={{ color: 'var(--muted)' }}>USDC</span>
          </div>
          <ConnectKitButton />
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-6 pb-24">
        {/* Tabs */}
        <div className="flex gap-1 mb-6 p-1 rounded-xl" style={{ background: 'var(--surface-muted)' }}>
          {(['batch', 'history'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className="flex-1 py-2 text-sm font-medium rounded-lg capitalize transition-all"
              style={{
                background: activeTab === tab ? 'var(--surface-strong)' : 'transparent',
                color: activeTab === tab ? 'var(--ink)' : 'var(--muted)',
                boxShadow: activeTab === tab ? '0 1px 4px rgba(18,45,69,0.08)' : 'none',
              }}
            >
              {tab === 'batch' ? 'New Batch' : `History${history.length > 0 ? ` (${history.length})` : ''}`}
            </button>
          ))}
        </div>

        {/* ── BATCH TAB ── */}
        {activeTab === 'batch' && (
          <div className="flex flex-col gap-4">

            {/* Summary card */}
            <div className="rounded-2xl px-5 py-4" style={{ background: 'var(--surface)', border: '1px solid var(--border)', backdropFilter: 'blur(8px)' }}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium uppercase tracking-wide mb-1" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>Total batch amount</p>
                  <p className="display text-3xl font-semibold tabular-nums" style={{ color: 'var(--ink)' }}>
                    {totalRaw > 0n ? formatUsdc(totalRaw) : '0.00'}
                    <span className="text-base font-medium ml-1.5" style={{ color: 'var(--muted)' }}>USDC</span>
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xs font-medium uppercase tracking-wide mb-1" style={{ color: 'var(--subtle)', letterSpacing: '0.08em' }}>Recipients</p>
                  <p className="display text-3xl font-semibold tabular-nums" style={{ color: 'var(--ink)' }}>{validRows.length}</p>
                </div>
              </div>
              {usdcBalance !== undefined && totalRaw > usdcBalance && (
                <p className="mt-3 text-xs font-medium px-3 py-2 rounded-lg" style={{ background: '#fff3f5', color: 'var(--danger)' }}>
                  Insufficient balance. You have {formatUsdcBalance(usdcBalance)} USDC but need {formatUsdc(totalRaw)} USDC.
                </p>
              )}
            </div>

            {/* CSV import */}
            <div
              className="rounded-xl px-4 py-3 flex items-center gap-3 cursor-pointer transition-colors"
              style={{ border: '1px dashed var(--border-strong)', background: 'var(--surface)' }}
              onDragOver={e => e.preventDefault()}
              onDrop={handleCsvDrop}
            >
              <Upload size={16} style={{ color: 'var(--subtle)', flexShrink: 0 }} />
              <div className="flex-1 min-w-0">
                <p className="text-sm" style={{ color: 'var(--muted)' }}>
                  Drop a CSV file or{' '}
                  <label className="font-medium cursor-pointer" style={{ color: 'var(--accent-hover)', textDecoration: 'underline' }}>
                    browse
                    <input type="file" accept=".csv,.txt" className="hidden" onChange={handleCsvInput} />
                  </label>
                  {' '}— one row: <span className="mono text-xs">address, amount</span>
                </p>
              </div>
            </div>
            {csvError && <p className="text-xs -mt-2" style={{ color: 'var(--danger)' }}>{csvError}</p>}

            {/* Recipient rows */}
            <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid var(--border)', background: 'var(--surface)' }}>
              <div className="px-4 pt-4 pb-2">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>Recipients</h3>
                  <div className="flex items-center gap-2">
                    <span className="text-xs" style={{ color: 'var(--subtle)' }}>Address</span>
                    <span className="text-xs sm:w-36 text-right" style={{ color: 'var(--subtle)' }}>USDC</span>
                    <span className="w-8" />
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  {rows.map((row, idx) => (
                    <PayrollRowInput
                      key={row.id}
                      row={row}
                      idx={idx}
                      onChange={handleRowChange}
                      onRemove={handleRemoveRow}
                      canRemove={rows.length > 1}
                    />
                  ))}
                </div>
              </div>
              <div className="px-4 py-3 border-t" style={{ borderColor: 'var(--border)' }}>
                <button
                  onClick={handleAddRow}
                  disabled={rows.length >= 200}
                  className="flex items-center gap-2 text-sm font-medium transition-colors"
                  style={{ color: 'var(--accent-hover)' }}
                >
                  <Plus size={15} />
                  Add recipient
                </button>
              </div>
            </div>

            {/* Action — two-step: Approve → Dispatch */}
            <div className="rounded-2xl p-4 flex flex-col gap-3" style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}>
              {/* Step 1 */}
              <div className="flex items-center gap-3">
                <div
                  className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold shrink-0"
                  style={{
                    background: approveSuccess ? 'var(--success)' : 'var(--surface-muted)',
                    color: approveSuccess ? '#fff' : 'var(--muted)',
                  }}
                >
                  {approveSuccess ? <CheckCircle2 size={14} /> : '1'}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium" style={{ color: 'var(--ink)' }}>Approve USDC</p>
                  <p className="text-xs" style={{ color: 'var(--subtle)' }}>Allow the contract to pull {totalRaw > 0n ? formatUsdc(totalRaw) : '—'} USDC</p>
                </div>
                <button
                  onClick={() => { try { handleApprove() } catch (e) { handleError(e) } }}
                  disabled={!hasValidBatch || isBusy || approveSuccess}
                  className="px-4 py-2 rounded-xl text-sm font-semibold transition-all"
                  style={{
                    background: approveSuccess ? 'var(--surface-muted)' : 'var(--accent)',
                    color: approveSuccess ? 'var(--muted)' : '#fff',
                    opacity: (!hasValidBatch || isBusy) && !approveSuccess ? 0.5 : 1,
                  }}
                >
                  {approvePending ? 'Confirm…' : approveConfirming ? 'Approving…' : approveSuccess ? 'Approved' : 'Approve'}
                </button>
              </div>

              <div style={{ height: 1, background: 'var(--border)' }} />

              {/* Step 2 */}
              <div className="flex items-center gap-3">
                <div
                  className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold shrink-0"
                  style={{
                    background: dispatchSuccess ? 'var(--success)' : 'var(--surface-muted)',
                    color: dispatchSuccess ? '#fff' : 'var(--muted)',
                  }}
                >
                  {dispatchSuccess ? <CheckCircle2 size={14} /> : '2'}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium" style={{ color: 'var(--ink)' }}>Dispatch payroll</p>
                  <p className="text-xs" style={{ color: 'var(--subtle)' }}>Send USDC to {validRows.length || '—'} recipient{validRows.length !== 1 ? 's' : ''} in one tx</p>
                </div>
                <button
                  onClick={() => { try { handleDispatch() } catch (e) { handleError(e) } }}
                  disabled={!approveSuccess || !hasValidBatch || isBusy || dispatchSuccess}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all"
                  style={{
                    background: 'var(--accent)',
                    color: '#fff',
                    opacity: (!approveSuccess || !hasValidBatch || isBusy || dispatchSuccess) ? 0.4 : 1,
                  }}
                >
                  <Send size={14} />
                  {dispatchPending ? 'Confirm…' : dispatchConfirming ? 'Sending…' : dispatchSuccess ? 'Sent!' : 'Dispatch'}
                </button>
              </div>

              {dispatchHash && !dispatchSuccess && (
                <p className="text-xs" style={{ color: 'var(--subtle)' }}>
                  Tx: <a href={buildTxExplorerUrl(CHAIN_ID, dispatchHash)} target="_blank" rel="noopener noreferrer" className="mono hover:underline" style={{ color: 'var(--accent-hover)' }}>{shortAddr(dispatchHash)}</a>
                </p>
              )}
              {dispatchSuccess && dispatchHash && (
                <a
                  href={buildTxExplorerUrl(CHAIN_ID, dispatchHash)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-xs font-medium"
                  style={{ color: 'var(--success)' }}
                >
                  <CheckCircle2 size={13} /> Payroll confirmed — view on explorer
                </a>
              )}

              {filledRows.length > 0 && !approveSuccess && !isBusy && (
                <p className="text-xs" style={{ color: 'var(--subtle)' }}>
                  Step 1: approve {validRows.length > 0 ? formatUsdc(totalRaw) : '—'} USDC to the contract, then dispatch in one atomic transaction.
                </p>
              )}
            </div>
          </div>
        )}

        {/* ── HISTORY TAB ── */}
        {activeTab === 'history' && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="display text-lg font-semibold" style={{ color: 'var(--ink)' }}>Transaction history</h2>
              <p className="text-xs" style={{ color: 'var(--subtle)' }}>This session only</p>
            </div>
            <HistoryTable entries={history} />
          </div>
        )}
      </main>
    </div>
  )
}
