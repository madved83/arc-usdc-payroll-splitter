yes
# BatchPayroll Smart Contract — Design Document

**Status:** Draft  
**Target Chain:** Arc Testnet (Chain ID 5042002) / Arc Mainnet  
**Language/Toolchain:** Solidity 0.8.28, Foundry (forge 0.3.x)  
**Review Tracker:**  
- [ ] Design Review  
- [ ] Security Review  
- [ ] Ops Review  

---

## Action Items (living)

_Starts empty; filled after each review round._

---

## Goals / Non-Goals

### Goals
- Let an employer/payer approve a single USDC amount and call one contract function to atomically distribute USDC to N recipients.
- Emit a single `BatchDispatched` event per batch that records every recipient + amount, making the transaction queryable from the frontend for history.
- Keep the contract permissionless — any caller may use it as a payroll dispatcher; no admin or owner role required.
- Hold zero funds at rest — pull USDC from the caller in the same transaction that pushes to recipients.

### Non-Goals
- No escrow or deferred payment — funds move in the same tx that's called.
- No scheduling or recurring payment logic.
- No upgradeability — a fixed, immutable contract is the safest default for a permissionless dispatcher.
- No fee or treasury extraction by the contract.
- No cross-chain distribution (single-chain USDC transfers only).

---

## Requirements

### Functional
1. The caller specifies an array of `(address recipient, uint256 amount)` pairs.
2. The contract pulls `sum(amounts)` USDC from the caller via `transferFrom` (requires prior approval).
3. Each recipient receives exactly their stated amount in a single atomic transaction.
4. If any transfer fails (e.g. blacklisted recipient on a USDC contract), the entire batch reverts.
5. An empty batch reverts immediately.
6. A batch with a zero-amount entry reverts.
7. A batch with a zero-address recipient reverts.
8. Maximum batch size is capped (e.g. 200 entries) to prevent gas exhaustion / DoS.

### Security
- No path allows the contract to retain USDC at rest.
- No path allows a non-caller to drain caller's approved USDC via this contract (non-reentrant, exact-amount pull).
- Batch sum computed on-chain; caller cannot manipulate it after approval.
- `SafeERC20` used for all token interactions.
- Re-entrancy guard on the dispatch function.

---

## Terminology & Actors

| Actor | On/Off-chain | Trust Level | What they can do |
|---|---|---|---|
| Payer (caller) | On-chain EOA or contract | Untrusted | Approves USDC to contract, calls `dispatchBatch` |
| Recipient | On-chain EOA or contract | Untrusted | Receives USDC; cannot initiate or modify a batch |
| USDC contract | On-chain | Trusted | ERC-20 token; may have built-in blocklist (Circle FiatToken) |
| BatchPayroll contract | On-chain | N/A — no privileged role | Stateless dispatcher; reads no oracles, calls no external logic beyond USDC |

---

## Language / Runtime

- **Solidity 0.8.28** — built-in overflow/underflow protection, custom errors, `revert` without reason strings.
- **EVM hardfork:** Paris (Arc Testnet requires Paris; no Cancun opcodes).
- **OpenZeppelin 5.1.0** — `SafeERC20`, `ReentrancyGuard`. (5.2.0+ uses `mcopy` / Cancun opcode; not usable on Arc Paris EVM.)

---

## Transaction & Execution Model

Execution is atomic: either all state changes commit (all transfers succeed) or all revert.  
External call surface:
1. `USDC.transferFrom(payer, address(this), total)` — pulls aggregate.
2. `USDC.transfer(recipient[i], amounts[i])` — N outbound pushes.

CEI discipline applied: checks and total-sum computation happen before any external call. `ReentrancyGuard` (`nonReentrant`) guards `dispatchBatch` since it makes multiple external calls.

---

## Chain Standards & Interfaces

- Interacts with IERC20 (ERC-20).
- Uses `SafeERC20` wrapper — handles non-standard ERC-20s that return `false` instead of reverting.
- No signature verification, no Permit2.

---

## Architecture Overview

```mermaid
sequenceDiagram
    participant Payer
    participant USDC
    participant BatchPayroll

    Payer->>USDC: approve(BatchPayroll, totalAmount)
    Payer->>BatchPayroll: dispatchBatch(usdc, recipients, amounts)
    BatchPayroll->>BatchPayroll: validate inputs, compute total
    BatchPayroll->>USDC: transferFrom(payer, BatchPayroll, total)
    loop for each recipient
        BatchPayroll->>USDC: transfer(recipient[i], amounts[i])
    end
    BatchPayroll-->>Payer: emit BatchDispatched(...)
```

**Flow of funds:**

| Step | Who moves what | Invariant |
|---|---|---|
| 1 | Payer approves sum(amounts) to BatchPayroll | Payer USDC balance unchanged |
| 2 | `transferFrom` pulls sum(amounts) from Payer to BatchPayroll | BatchPayroll balance = sum(amounts) |
| 3 | N `transfer` calls push each amount to each recipient | BatchPayroll balance decrements by amounts[i] each iteration |
| 4 | After all transfers | BatchPayroll balance = 0 (resting-state invariant) |

**Resting-state invariant:** `USDC.balanceOf(BatchPayroll) == 0` after every successful `dispatchBatch` call.

---

## Contract Design

### Roles

No privileged roles. The contract is permissionless and immutable.

### Storage Layout

```
address public immutable usdc;         // set in constructor, never changes
uint256 public constant MAX_BATCH = 200; // upper bound on batch size
```

No dynamic storage (no mappings, no arrays in state). The contract is near-stateless.

### Functions (Write)

#### `constructor(address _usdc)`
- **Caller:** deployer (once).
- **State mutated:** sets `usdc` immutable.
- **Revert:** `_usdc == address(0)`.

#### `dispatchBatch(address[] calldata recipients, uint256[] calldata amounts)`
- **Caller:** any address (payer).
- **State mutated:** no contract storage — moves tokens via ERC-20.
- **Events:** `BatchDispatched(address indexed payer, uint256 total, address[] recipients, uint256[] amounts)`.
- **Revert conditions:**
  - `recipients.length == 0`
  - `recipients.length != amounts.length`
  - `recipients.length > MAX_BATCH`
  - Any `amounts[i] == 0`
  - Any `recipients[i] == address(0)`
  - `transferFrom` fails (insufficient allowance / balance / blacklisted payer)
  - Any `transfer` fails (blacklisted recipient / USDC issue)
  - Re-entrancy detected

### Events

```solidity
event BatchDispatched(
    address indexed payer,
    uint256 total,
    address[] recipients,
    uint256[] amounts
);
```

Indexed `payer` enables filtering by sender. `total`, `recipients`, and `amounts` let the frontend reconstruct history from a single event.

---

## Deployment & Initialization

- **Constructor arg:** `address _usdc` — the USDC ERC-20 address for the target chain.
  - Arc Testnet: `0x3600000000000000000000000000000000000000`
- **No `initialize`** — immutable, not upgradeable.
- **No proxy.**

---

## Upgradeability

None — immutable contract. Migration story: deploy a new contract at a new address and update the frontend config. No dual-run needed (stateless dispatcher holds no user state).

---

## Key Management & Signing

No off-chain authorization. All calls are standard EVM transactions.

---

## Security Considerations

| Vulnerability | Applicable? | Mitigation |
|---|---|---|
| Reentrancy | Yes — multiple external calls | `nonReentrant` on `dispatchBatch`; CEI ordering (all checks before first external call) |
| Access control | No privileged roles | N/A — permissionless is the design |
| Integer overflow/underflow | Solidity 0.8.28 checked | Total sum accumulation: `total += amounts[i]` is checked arithmetic |
| Unchecked external call / return | Yes | `SafeERC20.safeTransferFrom` + `SafeERC20.safeTransfer` on all token ops |
| Fee-on-transfer / rebasing tokens | USDC is fixed — not applicable | Design accepts only the declared USDC address; fee-on-transfer would break the sum invariant but Circle USDC has none |
| Signature replay | Not applicable | No off-chain signatures |
| Front-running / MEV | Low risk | Batch content is known at submission; no extractable value within the contract |
| Flash-loan / price manipulation | Not applicable | No oracle, no price-sensitive logic |
| Oracle manipulation | Not applicable | No oracle |
| Denial of service | Yes — unbounded loop | `MAX_BATCH = 200` cap; per-recipient cost is bounded |
| Delegatecall / proxy safety | Not applicable | Immutable, no proxy |
| Timestamp / block dependence | Not applicable | No time-dependent logic |
| Approval persistence | Yes | `transferFrom` uses only the exact computed total; no dangling max-approvals on the contract side |
| Centralization risk | Not applicable | No privileged roles; contract is permissionless |

---

## Trust Model & Threat Analysis

| Actor | Worst-case if compromised | Mitigation | Detection |
|---|---|---|---|
| Payer (caller) | Sends funds to wrong recipients | Not the contract's responsibility — payer constructs the batch | Off-chain verification before signing |
| USDC contract | Blacklisted recipient causes full revert | Design intent — atomic safety | Payer must check recipients before batching |

No contract-level privileged key to compromise.

---

## Emergency Response & Circuit Breakers

No pause mechanism — the contract is permissionless and holds no funds at rest. If a critical bug is found, the frontend is updated to point to a redeployed contract. No rescue mechanism needed (zero resting balance).

---

## Failure Scenarios

1. **One recipient is blacklisted by USDC:** `transfer` reverts, entire batch reverts, payer's funds are safe (never left their wallet beyond approval).
2. **Payer's balance < total:** `transferFrom` reverts, batch reverts.
3. **Payer's allowance < total:** `transferFrom` reverts, batch reverts.
4. **Gas exhaustion (very large batch):** `MAX_BATCH = 200` cap limits worst-case gas. If Arc block gas limit tightens, the frontend should warn at large batch sizes.
5. **Re-entrant recipient contract:** `nonReentrant` causes the outer call to revert; all state rolled back.

---

## Priorities & Tradeoffs

| Decision | Tradeoff | Rationale |
|---|---|---|
| Pull-then-push vs. pull-only | Pull-then-push requires one `transferFrom` + N `transfer`. Pull-only (N `transferFrom`) would require N approvals | Single approval is the standard payroll UX |
| No owner/pause | Removes admin risk surface; no pause if a bug is found | Contract is stateless and holds nothing; risk is low; freeze-ability adds more risk than it removes |
| Immutable USDC address | Cannot be updated post-deploy | Prevents address-swap attack; Arc USDC address is stable |
| `MAX_BATCH = 200` | Restricts large payrolls to multiple txs | Prevents gas exhaustion; Arc block gas allows ~200 ERC-20 transfers safely |

---

## Testing Strategy

- **Unit tests (Foundry `.t.sol`):** happy path, revert paths, events, fuzz batch sizes and amounts, invariant (resting balance = 0).
- **Static analysis:** Slither on production source.
- **Fork/integration tests:** against Arc Testnet.
- Run: `forge test --gas-report`

---

## Third-party Libraries

| Library | Version | Dependency? | Why | Security reviewed? |
|---|---|---|---|---|
| @openzeppelin/contracts | 5.1.0 | Yes (baked in) | SafeERC20, ReentrancyGuard | Yes (OZ audited) |

---

## Monitoring & Alerting

| Event | Threshold | Severity | Playbook |
|---|---|---|---|
| `BatchDispatched` | Any emit | Info | Log payer + total for off-chain records |
| Revert on `dispatchBatch` | Any | Warning | Inspect revert reason; check allowance/balance/blacklist |

---

## Common Patterns / Worked Example

**Single batch of 3 recipients:**

1. Payer calls `USDC.approve(BatchPayroll, 300_000_000)` (300 USDC at 6 decimals).
2. Payer calls `BatchPayroll.dispatchBatch([alice, bob, carol], [100_000_000, 150_000_000, 50_000_000])`.
3. Contract validates: lengths match, no zeros, no zero-addresses, total = 300_000_000.
4. `safeTransferFrom(payer, BatchPayroll, 300_000_000)` — BatchPayroll now holds 300 USDC.
5. `safeTransfer(alice, 100_000_000)` — Alice +100 USDC.
6. `safeTransfer(bob, 150_000_000)` — Bob +150 USDC.
7. `safeTransfer(carol, 50_000_000)` — Carol +50 USDC.
8. `BatchPayroll.USDC.balanceOf(BatchPayroll) == 0` — resting state.
9. `BatchDispatched(payer, 300_000_000, [alice, bob, carol], [100_000_000, 150_000_000, 50_000_000])` emitted.
