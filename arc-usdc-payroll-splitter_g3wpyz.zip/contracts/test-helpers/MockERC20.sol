// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";

/// @dev Minimal ERC-20 mock for use in Foundry unit tests.
///      Exposes a public `mint` so test setUp can seed arbitrary balances,
///      and overrides `decimals()` to return 6 (USDC-like).
contract MockERC20 is ERC20 {
    uint8 private immutable _decimals;

    constructor(string memory name_, string memory symbol_, uint8 decimals_)
        ERC20(name_, symbol_)
    {
        _decimals = decimals_;
    }

    function decimals() public view override returns (uint8) {
        return _decimals;
    }

    /// @dev Mint `amount` tokens to `to`. No access control — tests only.
    function mint(address to, uint256 amount) external {
        _mint(to, amount);
    }
}
